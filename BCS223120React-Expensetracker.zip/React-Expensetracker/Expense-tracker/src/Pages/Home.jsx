import { useEffect, useState } from "react";
import axios from "axios";
import Header from "../Components/Header";
import NavBar from "../Components/NavBar";
import Footer from "../Components/Footer";

const backendUrl = "http://localhost:5000/api/expenses";

const Home = () => {
  const [expenses, setExpenses] = useState([]);
  const [total, setTotal] = useState(0);
  const [form, setForm] = useState({ category: "", amount: "", date: "" });
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    fetchExpenses();
  }, []);

  const fetchExpenses = async () => {
    const res = await axios.get(backendUrl);
    setExpenses(res.data);
    const totalSum = res.data.reduce((acc, e) => acc + e.amount, 0);
    setTotal(totalSum);
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.id]: e.target.value });
  };

  const handleAddOrUpdate = async () => {
    const { category, amount, date } = form;
    if (!category || !amount || !date) {
      alert("Please fill all fields");
      return;
    }

    const expenseData = { category, amount: Number(amount), date };

    if (editingId) {
      await axios.put(`${backendUrl}/${editingId}`, expenseData);
      setEditingId(null);
    } else {
      await axios.post(backendUrl, expenseData);
    }

    setForm({ category: "", amount: "", date: "" });
    fetchExpenses();
  };

  const handleDelete = async (id) => {
    await axios.delete(`${backendUrl}/${id}`);
    fetchExpenses();
  };

  const handleEdit = (expense) => {
    setForm({ ...expense, amount: String(expense.amount) });
    setEditingId(expense._id);
  };

  return (
    <>
      <Header />
      <NavBar />
      <div className="container mt-4">
        <h1 className="headers">Expense Tracker App</h1>
        <div className="row mb-3">
          <div className="col-12 col-lg-3 mb-3">
            <label>Category</label>
            <select id="category" className="form-control" value={form.category} onChange={handleChange}>
              <option value="">Select</option>
              <option value="Grocery">Grocery</option>
              <option value="Rent">Rent</option>
              <option value="Transport">Transport</option>
              <option value="Food">Food</option>
            </select>
          </div>
          <div className="col-12 col-lg-3 mb-3">
            <label>Amount</label>
            <input type="number" id="amount" className="form-control" value={form.amount} onChange={handleChange} />
          </div>
          <div className="col-12 col-lg-3 mb-3">
            <label>Date</label>
            <input type="date" id="date" className="form-control" value={form.date} onChange={handleChange} />
          </div>
          <div className="col-12 col-lg-3 mb-3 d-flex align-items-end">
            <button className="btn btn-success" onClick={handleAddOrUpdate}>
              {editingId ? "Update" : "Add"}
            </button>
          </div>
        </div>

        <h2 className="headers">Expense List</h2>
        <table className="table">
          <thead>
            <tr>
              <th>Category</th>
              <th>Amount</th>
              <th>Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {expenses.map((expense) => (
              <tr key={expense._id}>
                <td>{expense.category}</td>
                <td>{expense.amount}</td>
                <td>{expense.date}</td>
                <td>
                  <button className="btn btn-warning btn-sm me-2" onClick={() => handleEdit(expense)}>Edit</button>
                  <button className="btn btn-danger btn-sm" onClick={() => handleDelete(expense._id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <td><strong>Total</strong></td>
              <td>{total}</td>
              <td></td>
              <td></td>
            </tr>
          </tfoot>
        </table>
      </div>
      <Footer />
    </>
  );
};

export default Home;
