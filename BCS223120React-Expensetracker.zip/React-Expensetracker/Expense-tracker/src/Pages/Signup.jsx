import { useState } from "react";
import Header from "../Components/Header";
import NavBar from "../Components/NavBar";
import Footer from "../Components/Footer";
import { useNavigate } from "react-router-dom";

const Signup = () => {
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (password !== confirm) {
      alert("Passwords do not match!");
    } else {
      navigate("/login");
    }
  };

  return (
    <>
      <Header />
      <NavBar />
      <div className="container mt-5 col-lg-6">
        <h1 className="headers">Sign Up</h1>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label className="form-label">Username</label>
            <input type="text" className="form-control" required />
          </div>
          <div className="mb-3">
            <label className="form-label">Email</label>
            <input type="email" className="form-control" required />
          </div>
          <div className="mb-3">
            <label className="form-label">Password</label>
            <input type="password" className="form-control" required onChange={e => setPassword(e.target.value)} />
          </div>
          <div className="mb-3">
            <label className="form-label">Confirm Password</label>
            <input type="password" className="form-control" required onChange={e => setConfirm(e.target.value)} />
          </div>
          <button type="submit" className="btn btn-success">Sign Up</button>
        </form>
        <p className="mt-3">Already have an account? <a href="/login">Login here</a></p>
      </div>
      <Footer />
    </>
  );
};

export default Signup;
