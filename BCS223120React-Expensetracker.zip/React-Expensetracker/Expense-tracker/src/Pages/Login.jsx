import Header from "../Components/Header";
import NavBar from "../Components/NavBar";
import Footer from "../Components/Footer";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    navigate("/");
  };

  return (
    <>
      <Header />
      <NavBar />
      <div className="container mt-5 col-lg-6">
        <h1 className="headers">Login</h1>
        <form onSubmit={handleLogin}>
          <div className="mb-3">
            <label className="form-label">Username</label>
            <input type="text" className="form-control" required />
          </div>
          <div className="mb-3">
            <label className="form-label">Password</label>
            <input type="password" className="form-control" required />
          </div>
          <button type="submit" className="btn btn-success">Login</button>
        </form>
        <p className="mt-3">Don't have an account? <a href="/signup">Sign up here</a></p>
      </div>
      <Footer />
    </>
  );
};

export default Login;
