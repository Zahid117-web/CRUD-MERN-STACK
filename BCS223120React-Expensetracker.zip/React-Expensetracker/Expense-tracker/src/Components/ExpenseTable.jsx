const ExpenseTable = ({ expenses, onDelete }) => {
  const totalAmount = expenses.reduce((sum, e) => sum + e.amount, 0);

  return (
    <div className="expense_table">
      <h2 className="headers">Expense List</h2>
      <table className="table">
        <thead>
          <tr>
            <th>Category</th>
            <th>Amount</th>
            <th>Date</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          {expenses.map((expense, idx) => (
            <tr key={idx}>
              <td>{expense.category}</td>
              <td>{expense.amount}</td>
              <td>{expense.date}</td>
              <td>
                <button className="btn btn-danger btn-sm" onClick={() => onDelete(idx)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr>
            <td><strong>Total</strong></td>
            <td>{totalAmount}</td>
            <td></td>
            <td></td>
          </tr>
        </tfoot>
      </table>
    </div>
  );
};

export default ExpenseTable;
