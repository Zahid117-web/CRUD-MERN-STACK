import { useState } from "react";

const ExpenseForm = ({ onAddExpense }) => {
  const [category, setCategory] = useState("Grocery");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!amount || !date) {
      alert("Please fill all fields correctly.");
      return;
    }

    onAddExpense({ category, amount: Number(amount), date });
    setAmount("");
    setDate("");
  };

  return (
    <form className="row mb-3" onSubmit={handleSubmit}>
      <div className="col-12 col-lg-3 mb-3">
        <label>Category</label>
        <select className="form-control" value={category} onChange={e => setCategory(e.target.value)}>
          <option value="Grocery">Grocery</option>
          <option value="Rent">Rent</option>
          <option value="Transport">Transport</option>
          <option value="Food">Food</option>
        </select>
      </div>
      <div className="col-12 col-lg-3 mb-3">
        <label>Amount</label>
        <input className="form-control" type="number" min="1" value={amount} onChange={e => setAmount(e.target.value)} />
      </div>
      <div className="col-12 col-lg-3 mb-3">
        <label>Date</label>
        <input className="form-control" type="date" value={date} onChange={e => setDate(e.target.value)} />
      </div>
      <div className="col-12 col-lg-3 mb-3 d-flex align-items-end">
        <button type="submit" className="btn btn-success">Add</button>
      </div>
    </form>
  );
};

export default ExpenseForm;
