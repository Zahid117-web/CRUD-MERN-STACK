import { Link } from "react-router-dom";

const NavBar = () => (
  <nav className="nav-menu">
    <Link to="/">Home</Link>
    <Link to="/login">Login</Link>
    <Link to="/signup">Sign Up</Link>
  </nav>
);

export default NavBar;