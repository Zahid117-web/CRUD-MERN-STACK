const Footer = () => (
  <footer className="site-footer">
    <p>Expense Tracker Website</p>
  </footer>
);

export default Footer;